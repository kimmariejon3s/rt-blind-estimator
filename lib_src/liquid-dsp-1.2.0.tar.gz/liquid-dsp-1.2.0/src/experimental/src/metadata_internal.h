//
//
//

#ifndef __LIQUID_METADATA_INTERNAL_H__
#define __LIQUID_METADATA_INTERNAL_H__

#include "metadata.h"

unsigned int  metadata_get_key_id(metadata _m, char *_name);
void metadata_increase_mem(metadata _m);

#endif // __LIQUID_METADATA_INTERNAL_H__

