#######################################################################
#
#  liquid-dsp : experimental module
#
#######################################################################

This module holds the experimental objects and functions which are only
built if the '--enable-experimental' option is used during configure,
e.g.

  $ ./configure --enable-experimental

The purpose of this directory is to separate unstable objects from
officially being released and supported while still enabling their
development.  Some of these objects might never be officially released.

