// file: doc/tutorials/ofdmflexframe_init_tutorial.c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <liquid/liquid.h>

int main() {
    printf("done.\n");
    return 0;
}
